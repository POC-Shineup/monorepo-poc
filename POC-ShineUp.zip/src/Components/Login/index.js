import React from "react"
import "./styles.css";
import Button from "../../Components/forms/Buttons"

import {SignInWithGoogle} from "../../firebase/utils"

const Login = props => {

    const handleSubmit = async (e) => {
        e.preventDefault();
    }

    return(
        <div className="login">
            <div className="wrapper">
                <h2> Login</h2>
                <div className="formWrap">
                    <form onSubmit={handleSubmit}>
                        <div className="socialSignin">
                            <div className="rows">
                                <Button onClick={SignInWithGoogle}>
                                    Sign in with Google
                                </Button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    )
}

export default Login;