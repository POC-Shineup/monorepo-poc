//import { initializeApp } from "firebase/app";



// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyCxl6uz-_QAlIn7X3cyvIl1s1d42PclJFc",
  authDomain: "poc-shineup.firebaseapp.com",
  projectId: "poc-shineup",
  storageBucket: "poc-shineup.appspot.com",
  messagingSenderId: "443380842138",
  appId: "1:443380842138:web:a432e7b95ac9abcddfe923"
};

// Initialize Firebase
// const firebaseApp = firebase.initializeApp(firebaseConfig);

// const db = firebaseApp.firestore();

// const auth = firebase.auth();

// export { db, auth };

