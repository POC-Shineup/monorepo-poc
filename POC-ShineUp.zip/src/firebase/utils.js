import firebase, { firestore } from 'firebase/app';
import 'firebase/firestore';

import "firebase/auth";

import {firebaseConfig} from "./firebase"

firebase.initializeApp(firebaseConfig);

export const auth = firebase.auth();

export const fireStore = firebase.firestore();

const GoogleProvider = new firebase.auth.GoogleAuthProvider();

GoogleProvider.setCustomParameters({propmt: "select_account"});

//for google signin popup
export const SignInWithGoogle = () => auth.signInWithPopup(GoogleProvider);