import React, { Fragment, useEffect, useState } from 'react';
import { Route,Switch } from "react-router-dom";

import {auth} from "./firebase/utils"

import Navbar from "./Components/layout/Navbar";
import Homepage from "./Pages/Homepage"
import Register from "./Pages/Register";
import Signin from "./Pages/Signin";
import "./index.css"


function App() {

  const [currentUser, setCurrentUser] = useState(null);

  const authListner = () => {
    return null
  };

  useEffect(() => {
      authListner(auth.onAuthStateChanged(userAuth => {
        if(!userAuth) {
          return setCurrentUser(null);
        };
        setCurrentUser({userAuth});
      }))
      return authListner();
  },[]);



  console.log("currentUser", currentUser)

  return (
    <div className="App">

      <Switch>
          <Fragment>
      {/* <Route path="/"  render={() => {
        <Navbar currentUser={currentUser}/>
      }}
      /> */}
      <div className="main">
          <Route  path="/home" exact render={() => (
              <Homepage currentUser={currentUser} />
          )} />
          
          <Route  path="/register" exact render={() => (
              <Register currentUser={currentUser} />
          )} />

          <Route path="/signin" exact render={() => (
              <Signin currentUser={currentUser} />
          )} />

      </div>
      </Fragment>
      </Switch>


       
    </div>
  );
}

export default App;
