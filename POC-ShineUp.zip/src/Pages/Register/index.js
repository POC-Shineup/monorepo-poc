import React from 'react';
import Navbar from '../../Components/layout/Navbar';
const Register = props => {
  return (

    <div className="registerpage">
        <Navbar/>
        <h1 className="head">Register</h1>
    </div>
  );
};

export default Register; 